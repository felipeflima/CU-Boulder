#ifndef BOOK_H
#define BOOK_H
#include <iostream>
using namespace std;

class Book
{
    public:
        Book();
        Book(string, string);
        string getTitle();
        void setTitle(string);
        string getAuthor();
        void setAuthor(string);
    
    private:
        string title;
        string author;
};

#endif
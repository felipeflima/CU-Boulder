#ifndef USER_H
#define USER_H
#include <iostream>
using namespace std;

class User
{
    public:
        User();
        User(string, int*, int);
        string getUsername();
        void setUsername(string);
        int getRatingAt(int);
        bool setRatingAt(int,int);
        int getNumRatings();
        void setNumRatings(int);
        int getSize();
    
    private:
        string username;
        int ratings[200];
        int numRatings;
        int size;
};

#endif
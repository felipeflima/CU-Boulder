#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "User.h"
using namespace std;

User::User()
{
    username = "";
    numRatings = 0;
    size = 200;
    for (int i = 0; i < size; i++)
    {
        ratings[i] = -1;
    }
}

User::User(string usernameA, int ratingsA[], int numRatingsA)
{
    size = 200;
    username = usernameA;
    for (int i = 0; i < size; i++)
    {
        ratings[i] = ratingsA[i];
    }
    if (numRatingsA <= size)
    {
        numRatings = numRatingsA;
    }
}

string User::getUsername()
{
    return username;
}

void User::setUsername(string usernameA)
{
    username = usernameA;
}

int User::getRatingAt(int index)
{
    if (index < 0 || index >= 50)
    {
        return -1;
    }
    return ratings[index];
}

bool User::setRatingAt(int index,int value)
{
    if (index < 0 || index > size || value < 0 || value > 5)
    {
        return false;
    }
    else 
    {
        ratings[index] = value;
        return true;
    }
}

int User::getNumRatings()
{
    return numRatings;
}

void User::setNumRatings(int numRatingsA)
{
    numRatings = numRatingsA;
}

int User::getSize()
{
    return size;
}
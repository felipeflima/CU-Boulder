#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "Book.h"
using namespace std;

Book::Book() // Default constructor
{
    title = ""; // assign title to an empty string 
    author = ""; // assign author to an empty string 
}

Book::Book(string titleA, string authorA) // Parameterized constructor
{
    title = titleA; // assign title to titleA
    author = authorA; // assign author to authorA
}

string Book::getTitle()
{
    return title;
}

void Book::setTitle(string titleA)
{
    title = titleA;
}

string Book::getAuthor()
{
    return author;
}

void Book::setAuthor(string authorA)
{
    author = authorA;
}
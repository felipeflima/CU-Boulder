# Work by: Felipe Lima - 109290055
Contains:
- Part 1.2: len_ext_attack.py
- Part 2.1: generating_collisions.txt 
- Part 2.2: good.py and evil.py
#include "MovieTree.hpp"
#include <iostream>
#include <string>
#include<fstream>
#include <sstream>

using namespace std;

// MovieNode: node struct that will be stored in the MovieTree BST

MovieTree::MovieTree() {
  //write your code
}

MovieTree::~MovieTree() {
  //write your code
}

void MovieTree::printMovieInventory() {
   //write your code
}

void MovieTree::addMovieNode(int ranking, string title, int year, float rating) {
  //write your code
}

void MovieTree::findMovie(string title) {
  //write your code
}

void MovieTree::queryMovies(float rating, int year) {
  //write your code
}

void MovieTree::averageRating() {
  //write your code
}

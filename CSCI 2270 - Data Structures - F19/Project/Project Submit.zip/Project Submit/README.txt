Command lines used to compile and run the program.
Once in the right directory:

g++ -std=c++11 snowday.cpp main.cpp -o 1
./1


All files have to be in the same directory including hpp, cpp, and txt files. 

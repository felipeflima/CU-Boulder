#ifndef LEADERBOARD_H
#define LEADERBOARD_H


class Leaderboard
{
public:
    Leaderboard();
};

#endif // LEADERBOARD_H

#ifndef CARDS_H
#define CARDS_H


class Cards
{
public:
    Cards();
};


class SpecialCards: public Cards{
public:
    SpecialCards():
        Cards(){}
};

#endif // CARDS_H

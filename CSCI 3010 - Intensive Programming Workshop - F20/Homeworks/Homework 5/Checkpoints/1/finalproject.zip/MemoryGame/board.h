#ifndef BOARD_H
#define BOARD_H


class Board
{
public:
    Board();
};

#endif // BOARD_H

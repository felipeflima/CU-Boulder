#ifndef GRAPH_H
#define GRAPH_H

#include <QColor>
#include <QGraphicsItem>

class Graph:public QObject, public QGraphicsItem
{
    Q_OBJECT
public:
    Graph(int height, int x, int y);

    QRectF boundingRect() const override;
    QPainterPath shape() const override;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *item, QWidget *widget) override;

    int get_x(){return x_;}
    void set_x(int value){x_ = value;}

    int get_height(){return height_;}
    void set_height(int value){height_ = value;}

private:
    int height_;
    int x_;
    int y_;
    QColor bar_color;

    int const width_ = 20;

protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event) override;
};

#endif // GRAPH_H

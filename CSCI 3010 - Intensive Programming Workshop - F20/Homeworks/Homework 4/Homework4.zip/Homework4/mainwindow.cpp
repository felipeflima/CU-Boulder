#include <iostream>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QDebug>
#include <QTime>

#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QColor live(255,0,155);
    QColor dead(0,0,0);
//    QColor test(0,0,255);
    liveW_ = live;
    deadW_ = dead;

    playing_ = 0;
    speed_ = 0;
    turn_ = 0;

    QSlider *speedSlider = ui->speedSlider;
    connect(ui->playButton, SIGNAL(clicked()), this, SLOT(playGame()));
    connect(ui->stepButton, SIGNAL(clicked()), this, SLOT(stepGame()));
    connect(ui->pauseButton, SIGNAL(clicked()), this, SLOT(pauseGame()));
    connect(speedSlider, SIGNAL(valueChanged(int)), this, SLOT(SliderSlot(int)));
    connect(timer, SIGNAL(timeout()), this, SLOT(gamePlaying()));
    timer->start(1000);

    //connect(game, &GameOfLife::ChangeColorTurn, this, &MainWindow::ChangeColor);

    QGraphicsView * view = ui->graphicsView;
//    QGraphicsScene * scene = new QGraphicsScene;
    view->setScene(scene);

    view->setSceneRect(0,0,view->size().width()-2,view->size().height()-2);

    // we'll want to generate random numbers later so we're
    // going to seed our random number generator once
//    qsrand(static_cast<unsigned>(QTime::currentTime().msec()));
//    qsrand(QDateTime::currentMSecsSinceEpoch() / 1000);
//      srand(time(NULL));

    Position pos = {0,0};
    for(int i = 0; i < 15; i++){
        for(int j = 0; j < 35; j++){
            pos = {i,j};
            scene->addItem(game->get_cell(pos));
            game->num_neighbors(game->get_cell(pos));
            connect(game->get_cell(pos), &Cell::CellSelected, this, &MainWindow::ChangeColor);
            connect(game->get_cell(pos), &Cell::CellRightClicked, this, &MainWindow::CellRightClickedSlot);
//            connect(game, &GameOfLife::ChangeColorTurn, this, &MainWindow::ChangeColor);
        }
    }

    populationW_ = game->get_population();
    std::string p = "Population: " + std::to_string(populationW_) + " (";
    QString qp(p.c_str());
    ui->population->setText(qp + QString::number((populationW_/525.0)*100, 'g', 3) + "%)");


    scene->addItem(game->get_graph());
    scene->addItem(game->get_bar(0));

//  view->setFixedSize(4000,2000);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::playGame(){
//    qDebug("PLAY");
    playing_ = 1;
}

void MainWindow::gamePlaying(){
    if (playing_ == 1){
        stepGame();
        update();
    }
}

void MainWindow::ChangeColor(Cell * c){
    c->ChangeCellStatus();
    game->num_neighbors(c);
    if (c->get_status() == liveW_){
        game->set_population(game->get_population()+1);
    }
    else if (c->get_status() == deadW_){
        game->set_population(game->get_population()-1);
    }
    populationW_ = game->get_population();
    std::string p = "Population: " + std::to_string(populationW_) + " (";
    QString qp(p.c_str());
    ui->population->setText(qp + QString::number((populationW_/525.0)*100, 'g', 3) + "%)");
}

void MainWindow::CellRightClickedSlot(Cell * c){
    c->SetCellStatus(deadW_);
    game->num_neighbors(c);
    game->set_population(game->get_population()-1);
    populationW_ = game->get_population();
    std::string p = "Population: " + std::to_string(populationW_) + " (";
    QString qp(p.c_str());
    ui->population->setText(qp + QString::number((populationW_/525.0)*100, 'g', 3) + "%)");
}

void MainWindow::stepGame(){
    turn_++;
    game->turn();

    std::string t = "Turn: " + std::to_string(turn_);
    QString qt(t.c_str());
    ui->turn->setText(qt);

    populationW_ = game->get_population();
    std::string p = "Population: " + std::to_string(populationW_) + " (";
    QString qp(p.c_str());
    ui->population->setText(qp + QString::number((populationW_/525.0)*100, 'g', 3) + "%)");


    //    scene->addItem(game->get_bar(game->get_vec_size()-1));
    int max = std::max(0,game->get_vec_size()-35);
    qDebug() << max;
//    for (int i = max; i < game->get_vec_size(); i ++){
//        scene->removeItem(game->get_bar(i));
//        update();
//    }
    for (int i = max; i < game->get_vec_size(); i ++){
        scene->addItem(game->get_bar(i));
        update();
    }


//    qDebug() << "STEP";
}

void MainWindow::pauseGame(){
    playing_ = 0;
}

void MainWindow::SliderSlot(int value){
    qDebug() << value;
    speed_ = 100 - value;
    timer->start(speed_ * 10);
}
